import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../components/AuthContext';
import { addFolder, deleteFolder, fetchFolders } from '../database/firebaseCode';
import '../components/profile.css'

const Profile = () => {
  const { userID } = useAuth();
  const navigate = useNavigate();
  const [folders, setFolders] = useState([]);
  const [newFolderName, setNewFolderName] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!userID) {
      navigate('/Login');
    } else {
      fetchFolders(userID, setFolders);
    }
  }, [userID, navigate]);

  const handleAddFolder = async () => {
    if (newFolderName.trim() === '') {
      setError('Folder name cannot be empty');
      return;
    }
    if (folders.includes(newFolderName)) {
      setError('Folder name must be unique');
      return;
    }
    await addFolder(userID, newFolderName);
    setFolders([...folders, newFolderName]);
    setNewFolderName('');
    setError('');
  };

  const handleRemoveFolder = async (folderName) => {
    await deleteFolder(userID, folderName);
    setFolders(folders.filter(folder => folder !== folderName));
  };

  return (
    <div>
      <h1 className='tekstpr'>Profile Page</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div className='folderi'>
        {folders.map((folder) => (
          <div key={folder} style={{ display: 'flex', justifyContent: 'space-between', border: '1px solid black', padding: '10px', marginBottom: '10px' }}>
            <Link to={`/folder/${folder}`}>
              <p className='ime'>{folder}</p>
            </Link>
            <button onClick={() => handleRemoveFolder(folder)} style={{ backgroundColor: 'red', color: 'white', cursor: 'pointer' }}>
              🗑️
            </button>
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
            <input
              type="text"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              placeholder="Enter folder name"
            />
            <button onClick={handleAddFolder} style={{ cursor: 'pointer', fontSize: '24px' }}>
              ➕
            </button>
        </div>
      </div>
      <footer className='futer' style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
        
      </footer>
    </div>
  );
};

export default Profile;