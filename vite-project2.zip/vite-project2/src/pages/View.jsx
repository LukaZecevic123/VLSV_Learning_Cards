import React, { useEffect, useState } from 'react'
import Navbar from '../components/Navbar'
import '../components/navbar.css'
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../components/AuthContext';
import { fetchFolders, fetchUsers } from '../database/firebaseCode';
import { Spectator } from '../pages/Spectator';
import '../components/View.css'
import '../components/Profile.css'
function View() {

  const { setUserID } = useAuth();
  const [ usernameSearch, setUsernameSearch] = useState('');
  const [error, setError] = useState('');
  const [userList, setUserList] = useState([]);
  const [userFolders, setUserFolder] = useState([]);
  const navigate = useNavigate();
  const { searchID } = useParams();

  useEffect(() => {
    if(searchID != "undefined"){
        setUsernameSearch(searchID);
        handleSearch2();
    }
  }, [searchID])

  useEffect(() => {
    if(userList.length == 0){return}
    if(userList.indexOf(usernameSearch) == -1){
        setUserList([]);
        setUserFolder([]);
    }
    else
    {
        fetchFolders(usernameSearch, setUserFolder);
    }
  }, [userList])

  useEffect(() =>{
    if(userFolders.length == 0){return}

  }, [userFolders])

  const handleSearch = (event) => { 
    event.preventDefault();
    fetchUsers(setUserList);
    navigate(`/View/${usernameSearch}`);
  };

  const handleSearch2 = () => { 
    fetchUsers(setUserList);
    navigate(`/View/${usernameSearch}`);
  };

return (
    <div>
        <header>
            <Navbar />
        </header>
        <main>  
            <div>
                <h1 className='center-text'>
                    View cards
                </h1>
            </div>
            <form onSubmit = {(event) => handleSearch(event)}>
                <div className='center-text2'>
                    Search for users:  <input onChange={(e) => {setUsernameSearch(e.target.value)}}/>
                    <button className='lupadugme'>
                        🔎
                    </button>
                </div>
            </form> 
            <div>
                <div className='center-text3'>FOLDERI:</div>
                
                <ul className='folderi1'>
                {userFolders.map((folder) =>
                    <div className='folder1' key={folder}><Link to = {`/Spectator/${usernameSearch}/${folder}`}> <p className='ime1'>{folder}</p> </Link></div>
                )}

                {error && <p style={{ color: 'red' }}>{error}</p>}
                </ul>
            </div>
        </main>
      <footer>
      </footer>
    </div>
)
}

export default View

