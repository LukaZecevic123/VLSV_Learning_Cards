import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import userImage from '../assets/userImage.png'; // Putanja do vaše slike
import Navbar from '../components/Navbar';
import { useAuth } from '../components/AuthContext';
import { signOut } from '../database/firebaseCode';
import '../components/Home.css'

const Home = () => {
  const { userID, setUserID } = useAuth();
  const [showDetails, setShowDetails] = useState(false);
  const navigate = useNavigate();

  const handleSignOut = () => {
    signOut(setUserID);
    setShowDetails(false);
    navigate('/Home');
  };

  const handleImageClick = () => {
    setShowDetails(!showDetails); // Prebacuje stanje između true i false
  };

  const handleLogIn = () => {
    navigate('/Login');
  }

  return (
    <div>
      <header>
        <Navbar />
      </header>
      <main>
        {userID ? (
          <div>
            <img className='slika'
              src={userImage}
              alt="User"
              onClick={handleImageClick}
              style={{ cursor: 'pointer' }}
            />
            {showDetails && (
              <div>
                <p className='dugmici3'>{userID}</p>
                <button className='dugmici2' onClick={handleSignOut}>Sign out</button>
              </div>
            )}
          </div>
        ) : (
          <button className="dugmici" onClick={handleLogIn}>Log in</button>
        )}
        <p className='tekst'>Dobrodošli na Learning Cards sajt!<br />
            Ovo je vaše digitalno mesto za učenje pomoću Flashcards sistema.<br />
            U svakom folderu nalaze se flash kartice 
            koje možete uređivati u delu Profile. <br /> 
            Na stranici View Cards moći ćete da testirate svoje znanje koristeći 
            sopstvene ili tuđe flash kartice. <br />
            Prijava i profil - ako još niste prijavljeni, 
            koristite opciju "Log in" u gornjem desnom uglu. <br />
            Na stranici profila možete videti sve kreirane foldere i upravljati njima. <br />
            Bezbednost je na prvom mestu - svi unosi su sigurni i zaštićeni. <br />
            Vaše informacije su bezbedne sa nama. <br />
            Hvala što koristite naš sajt!
        </p>
      </main>
      <footer></footer>
    </div>
  );
};

export default Home;
