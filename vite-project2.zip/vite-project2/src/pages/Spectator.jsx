import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { fetchCards } from '../database/firebaseCode';
import '../components/Spectator.css'; // Import CSS for animations
import '../components/View.css'

export const Spectator = () => {
  const { folderName } = useParams();
  const { searchID } = useParams(); 
  const [cards, setCards] = useState([]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchCards(searchID, folderName, setCards);
  }, [searchID, folderName]);

  useEffect(() => {
    if (cards.length > 0) {
      setCurrentCardIndex(0); // Reset index when cards are loaded
    }
  }, [cards]);

  const nextCard = () => {
    setFlipped(false); // Reset flip state to show the front side
    setTimeout(() => {
      if (cards.length > 1) {
        let newIndex;
        do {
          newIndex = Math.floor(Math.random() * cards.length);
        } while (newIndex === currentCardIndex);
        setCurrentCardIndex(newIndex);
      }
    }, 600); // Wait for the flip animation to finish (0.6s)
  };

  const toggleFlip = () => {
    setFlipped(!flipped);
  };

  const currentCard = cards[currentCardIndex];

  return (
    <div className="spectator-container">
      <header>
      </header>
      <main>
        <div className = "smajn">
            

          {currentCard && (
            <div className={`card-container ${flipped ? 'flipped' : ''}`} onClick={toggleFlip}>
              <div className="card-front">{currentCard.front}</div>
              <div className="card-back">{currentCard.back}</div>
            </div>
          )}
        </div>

        <div className="next-button">
          <button onClick={nextCard}>
              ⏩
          </button>
        </div>
      </main>
      <footer>
        <button onClick={() => { navigate(`/View/${searchID}`) }}>
            ⬅️
        </button>
      </footer>
    </div>
  );
};
