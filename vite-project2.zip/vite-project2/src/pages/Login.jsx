import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { useAuth } from '../components/AuthContext';
import { signIn } from '../database/firebaseCode';
import '../components/Login.css'

const Login = () => {
  const { setUserID } = useAuth();
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const navigate = useNavigate();

  const handleUsernameChange = (event) => {
    setUsernameInput(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPasswordInput(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if(signIn(usernameInput, passwordInput, setUserID)){
      navigate('/Home');
    }else{
      setError("**Username or password is wrong.");
    }

  };

  return (
    <div>
      <header>
        <Navbar />
      </header>
      <div className='kutija'>
      <main>
        <div className='login'><h3>LOGIN</h3></div>
        <form onSubmit={handleSubmit}>
          <div className='login'>
            Enter your username: <input type='text' className='login3' value={usernameInput} onChange={handleUsernameChange} />
          </div>
          <div className='login'>
            Enter your password: <input type='password' className='login3' value={passwordInput} onChange={handlePasswordChange} />
          </div>
          <div className='login'>
            You don't have an account?
            <Link to={"/Signup"}> Sign up! </Link>
          </div>
          <button type="submit" className='login2'>Confirm</button>
        </form>
        <button className='login2'>
          <Link to={"/Home"}> Cancel </Link>
        </button>
      </main>
      </div>
      <footer>
      </footer>
    </div>
  );
};

export default Login;