import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { fetchCards, deleteCard, setCard } from '../database/firebaseCode';
import { useAuth } from '../components/AuthContext';
import '../components/Folder.css'

const Folder = () => {
  const { folderName } = useParams();
  const { userID } = useAuth();
  const [cards, setCards] = useState([]);
  const [newCard, setNewCard] = useState({ front: '', back: '' });
  const [editingCard, setEditingCard] = useState(null);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    if (userID) {
      fetchCards(userID, folderName, setCards);
    }
  }, [userID, folderName]);

  const handleAddCard = async () => {
    if (newCard.front.trim() === '' || newCard.back.trim() === '') {
      setError('Both front and back text of the card cannot be empty');
      return;
    }
    const cardId = Date.now().toString();
    await setCard(userID, folderName, cardId, newCard);
    setCards([...cards, { id: cardId, ...newCard }]);
    setNewCard({ front: '', back: '' });
    setError('');
  };

  const handleDeleteCard = async (cardId) => {
    await deleteCard(userID, folderName, cardId);
    setCards(cards.filter(card => card.id !== cardId));
  };

  const handleEditCard = (card) => {
    setEditingCard(card);
  };

  const handleSaveEditCard = async () => {
    if (editingCard.front.trim() === '' || editingCard.back.trim() === '') {
      setError('Both front and back text of the card cannot be empty');
      return;
    }
    await setCard(userID, folderName, editingCard.id, editingCard);
    setCards(cards.map(card => (card.id === editingCard.id ? editingCard : card)));
    setEditingCard(null);
    setError('');
  };

  return (
    <div>
      <h1 className='naslov'>Folder: {folderName}</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <main className='foldermain1'>
        {cards.map((card) => (
          <div key={card.id} className='sos'>
            {editingCard && editingCard.id === card.id ? (
              <div className='stvari' style={{ display: 'flex', flexDirection: 'column' }}>
                <input
                  type="text"
                  value={editingCard.front}
                  onChange={(e) => setEditingCard({ ...editingCard, front: e.target.value })}
                  placeholder="Front"
                />
                <input
                  type="text"
                  value={editingCard.back}
                  onChange={(e) => setEditingCard({ ...editingCard, back: e.target.value })}
                  placeholder="Back"
                />
                <button onClick={handleSaveEditCard} style={{ cursor: 'pointer', fontSize: '24px' }}>
                  Save
                </button>
              </div>
            ) : (
              <div className='fak'>
                <p className='fak1'>{card.front}</p>
                <p className='fak1'>{card.back}</p>
              </div>
            )}
            <div className='upm' style={{ display: 'flex', flexDirection: 'row' , flexWrap: 'nowrap' }}>
              <button onClick={() => handleDeleteCard(card.id)} style={{ backgroundColor: 'red', color: 'white', cursor: 'pointer' }}>
                🗑️
              </button>
              <button onClick={() => handleEditCard(card)} style={{ backgroundColor: 'green', color: 'white', cursor: 'pointer', marginLeft: '10px' }}>
                ✏️
              </button>
            </div>
          </div>
        ))}
        <br />
        <br />
        <br />
        <br />
        <br />
        <div className='dodavanje' style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
          <input
            type="text" className='elementi'
            value={newCard.front}
            onChange={(e) => setNewCard({ ...newCard, front: e.target.value })}
            placeholder="Front"
          />
          <input
            type="text" className='elementi'
            value={newCard.back}
            onChange={(e) => setNewCard({ ...newCard, back: e.target.value })}
            placeholder="Back"
          />
          <button  onClick={handleAddCard} style={{ cursor: 'pointer', fontSize: '24px' }}>
            ➕
          </button>
        </div>

      </main>
      <footer style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
        <button className='levi' onClick={() => {navigate('/Profile')}}>
          ⬅️
        </button>
      </footer>
    </div>
  );
};

export default Folder;
