import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { useAuth } from '../components/AuthContext';
import { signUp } from '../database/firebaseCode';
import '../components/Signup.css'

const Signup = () => {
  const { UserID, setUserID } = useAuth();
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [error, setError] = useState('');

  const navigate = useNavigate();

  const handleUsernameChange = (event) => {
    setUsernameInput(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPasswordInput(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (passwordInput.length < 8) {
      setError("**Password must include 8 characters");
    } else {
      signUp(usernameInput, passwordInput, setUserID);
      if(!UserID){
        setError('');
        navigate('/Home');
      }else{
        setError('Username already exists.');
      }
    }
  };

  return (
    <div>
      <header>
        <Navbar />
      </header>
      <div className='kutija'>
      <main>
        <div className='signup'><h3>SIGN UP</h3></div>
        <form onSubmit={handleSubmit}>
          <div className='signup'>
            Enter your username: <input type='text' className='signup3' value={usernameInput} onChange={handleUsernameChange} />
          </div>
          <div className='signup'>
            Enter your password: <input type='password' className='signup3' value={passwordInput} onChange={handlePasswordChange} />
          </div>
          {error && <p style={{ color: 'red' }}>{error}</p>}
          <div className='signup'>
            You already have an account?
            <Link to={"/Login"}> Log in! </Link>
          </div>
          <button type="submit"  className='signup2'>Create</button>
        </form>
        <button className='signup2'>
          <Link to={"/Home"}> Cancel </Link>
        </button>
      </main>
      </div>
      <footer>

      </footer>
    </div>
  );
};

export default Signup;
