import React from 'react';
import ReactDOM from 'react-dom/client';
import { StrictMode } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Profile from './pages/Profile';
import View from './pages/View';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Navbar from './components/Navbar';
import Folder from './pages/Folder';
import { Spectator } from './pages/Spectator';
import { AuthProvider } from './components/AuthContext';
import './index.css';

const Main = () => (
  <BrowserRouter>
    <AuthProvider>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Home" element={<Home />} />
        <Route path="/Profile" element={<Profile />} />
        <Route path="/View" element={<View />} />
        <Route path="/View/:searchID" element={<View />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Signup" element={<Signup />} />
        <Route path="/Spectator/:searchID/:folderName" element={<Spectator />} />
        <Route path="/folder/:folderName" element={<Folder />} />
      </Routes>
    </AuthProvider>
  </BrowserRouter>
);

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <StrictMode>
    <Main />
  </StrictMode>
);
