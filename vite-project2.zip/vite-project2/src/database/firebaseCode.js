import { getDoc, getDocs, doc, collection, deleteDoc, setDoc, updateDoc } from 'firebase/firestore'
import { db } from './firebaseConfig'

const collName = 'cards'

const signUp = async (username, password, setUserId) => {
    if(username==''){return false}
    try{
        const userRef = doc(db, collName, username)
        const snap = await getDoc(userRef)
        if(!snap.exists()){
            await setDoc(userRef, {password:password, folders:[]})
            setUserId(userRef.id)
        }
    } catch (error) {
        console.error(error)
    }
}

const signIn = async (username, password, setUserId) => {
    if(username==''){return false}
    try{
        const userRef = doc(db, collName, username)
        const snap = await getDoc(userRef)
        if(snap.exists() && password==snap.data().password){
            setUserId(userRef.id)
        }
    } catch (error) {
        console.error(error)
    }
}

const signOut = async (setUserId) => {
    setUserId('')
}

//add or update card
const setCard = async (userId, folderId, cardId, cardData) => {
    try{
        const card = doc(db, collName, userId, folderId, cardId)
        const cardRef = setDoc(card, cardData)
        return cardRef.id
    } catch (error) {
        console.error(error)
    }
}

//delete card
const deleteCard = async (userId, folderId, cardId) => {
    try{
        const card = doc(db, collName, userId, folderId, cardId)
        await deleteDoc(card)
    } catch (error) {
        console.error(error)
    }
}

//passes username list to `setUsers`
const fetchUsers = async (setUsers) => {
    try{
        const snap = await getDocs(collection(db, collName))
        const users = snap.docs.map((doc)=>doc.id)
        setUsers(users)
    } catch (error) {
        console.error(error)
    }
}

const addFolder = async (userId, folderId) => {
    try{
        const user = doc(db, collName, userId)
        const userData = (await getDoc(user)).data()
        let foldersNew = userData.folders
        if(foldersNew.indexOf(folderId)!=-1){return false}
        foldersNew.push(folderId)
        await updateDoc(user, {folders:foldersNew})
    } catch (error) {
        console.error(error)
    }
}

const deleteFolder = async (userId, folderId) => {
    try{
        const user = doc(db, collName, userId)
        const userData = (await getDoc(user)).data()
        let folders = userData.folders
        const index = folders.indexOf(folderId)
        if(index==-1){ return false }
        folders.splice(index, 1)
        await updateDoc(user, {folders:folders})
        const snap = await getDocs(collection(db, collName, userId, folderId))
        snap.forEach(async (card)=>{
            await deleteDoc(doc(db, collName, userId, folderId, card.id))
        })
    } catch (error) {
        console.error(error)
    }
}

//passes folder list to `setFolders`
const fetchFolders = async (userId, setFolders) => {
    try{
        const user = doc(db, collName, userId)
        const userData = (await getDoc(user)).data()
        let folders = userData.folders
        setFolders(folders)
    } catch (error) {
        console.error(error)
    }
}

const fetchCards = async (userId, folderId, setCards) => {
    try{
        const snap = await getDocs(collection(db, collName, userId, folderId))
        const cards = snap.docs.map((doc)=>({id:doc.id, ...doc.data()}))
        setCards(cards)
    } catch (error) {
        console.error(error)
    }
}


export { setCard, fetchUsers, fetchFolders, fetchCards, deleteCard, signUp, signIn,
     signOut, addFolder, deleteFolder }
