import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCDakr6jTOy6VZWzvK2Ck9nNI4L6Rx84FM",
  authDomain: "test2-e9a4a.firebaseapp.com",
  projectId: "test2-e9a4a",
  storageBucket: "test2-e9a4a.firebasestorage.app",
  messagingSenderId: "745186553771",
  appId: "1:745186553771:web:e18196853aaf78d817acee",
  measurementId: "G-ZKTG2FQ2FK"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);